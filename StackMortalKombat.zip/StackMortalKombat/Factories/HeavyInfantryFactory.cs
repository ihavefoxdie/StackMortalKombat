﻿using StackMortalKombat.Units;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StackMortalKombat.Factories
{
    public class HeavyInfantryFactory : UnitFactory
    {
        public HeavyInfantryFactory()
        {
        }

        public override Unit CreateUnit()
        {
            throw new NotImplementedException();
        }
    }
}
