﻿// See https://aka.ms/new-console-template for more information
int n = 3;
Console.WriteLine(Convert.ToUInt32(n-3));


