﻿namespace StackMortalKombat.Interfaces;

public interface IHealable
{
    public void ReceiveHealing(uint value);
}
